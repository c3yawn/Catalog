package sample;

public class ControllerSettings {

    public void initialize() {

    }
}
